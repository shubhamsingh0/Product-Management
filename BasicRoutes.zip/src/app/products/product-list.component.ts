import { Component, OnInit } from '@angular/core';
import { Iproduct } from './product';
import { ProductService } from './product-list.service';
@Component(
    {
       // selector: 'pm-products',
        templateUrl: './product-list.component.html',
        styleUrls: ['./product-list.component.css']
    }
)
export class ProductListComponent implements OnInit {
    pageTitle: String = 'Product List';
    imageWidth: number = 50;
    imageMargin: number = 2;
    showImage: boolean = false;
    _showInInputBox: string;
   // errorMessage: String;
    get showInInputBox(): string {
        return this._showInInputBox;
    }
    set showInInputBox(value: string) {
        this._showInInputBox = value;
        this.filteredProducts = this._showInInputBox ? this.performFilter(this._showInInputBox) : this.products;
    }
    filteredProducts: Iproduct[];

    sh: String = 'Show';
    products: Iproduct[];

    constructor(private productService: ProductService) {

        //  this._showInInputBox=null;
    }
    performFilter(filterBy: string): Iproduct[] {
        filterBy = filterBy.toLocaleLowerCase();
        return this.products.filter((product: Iproduct) =>
            product.productName.toLocaleLowerCase().indexOf(filterBy) !== -1);
    }
    toggleImage(): void {
        this.showImage = !this.showImage;
    }

    ngOnInit(): void {

        this.productService.getProductList().subscribe(
            /*********OPTIONAL**********/

            //{
            //    next: products=>{this.products=products;
            //        this.filteredProducts=this.products; },
            //        error(err) {this.errorMessage=err;}
            // }
            (res) => {
                console.log(JSON.stringify(res));
                this.products = res;
                this.filteredProducts = this.products;
            }
        );

    }


    onRatingClicked(message: String): void {
        this.pageTitle = 'Product List : ' + message;
    }
}
